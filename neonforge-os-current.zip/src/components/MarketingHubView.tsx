import React, { useState } from 'react';
import { 
  Flame, 
  Tag, 
  Share2, 
  Copy, 
  Check, 
  Sparkles, 
  MessageSquare, 
  Twitter, 
  Video, 
  Bookmark,
  ExternalLink,
  Search
} from 'lucide-react';
import { DigitalProduct } from '../types';
import { playSound } from '../utils/audio';

interface MarketingHubViewProps {
  products: DigitalProduct[];
}

export const MarketingHubView: React.FC<MarketingHubViewProps> = ({ products }) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const selectedProduct = products.find(p => p.id === selectedProductId) || products[0];

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    playSound('click');
    setTimeout(() => setCopiedKey(null), 1500);
  };

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Flame className="w-5 h-5 text-amber-400" />
            <h2 className="font-mono text-lg font-bold uppercase text-white tracking-wide">
              VIRAL MARKETING REACTOR & SEO SUITE (MAYA & SAGE)
            </h2>
          </div>
          <p className="text-xs text-slate-300">
            Autonomous multi-platform traffic engine. Generates organic Reddit value posts, X/Twitter threads, TikTok video hook storyboards, and 13-tag Etsy algorithmic rankings.
          </p>
        </div>

        {/* Product Picker */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-mono text-slate-400 uppercase">Product Campaign:</label>
          <select
            value={selectedProductId}
            onChange={(e) => setSelectedProductId(e.target.value)}
            className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-cyan-300 outline-none focus:border-cyan-400"
          >
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title.slice(0, 35)}...
              </option>
            ))}
          </select>
        </div>
      </div>

      {selectedProduct && (
        <div className="space-y-6">
          {/* Etsy 13-Tag SEO Command */}
          <div className="rounded-xl border border-blue-500/40 bg-[#090d18] p-5 shadow-xl glow-cyan space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-500/40 uppercase font-bold">
                  SAGE · ETSY ALGORITHMIC RANKING RADAR
                </span>
                <h3 className="font-mono text-base font-bold text-white mt-1">
                  13 High-Intent Etsy Search Tags
                </h3>
              </div>

              <div className="flex items-center gap-2 text-xs font-mono text-blue-300">
                <span>Etsy Search Volume Index:</span>
                <span className="font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  {selectedProduct.etsyOptimization.etsySearchVolumeScore} / 100 (HIGH DEMAND)
                </span>
              </div>
            </div>

            <div>
              <div className="text-[11px] font-mono uppercase text-slate-400 mb-1 flex items-center justify-between">
                <span>Optimized Long-Tail Title:</span>
                <button
                  onClick={() => handleCopy(selectedProduct.etsyOptimization.seoTitle, 'title')}
                  className="text-cyan-400 hover:text-white flex items-center gap-1"
                >
                  {copiedKey === 'title' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'title' ? 'Copied' : 'Copy Full Title'}</span>
                </button>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200">
                {selectedProduct.etsyOptimization.seoTitle}
              </div>
            </div>

            <div>
              <div className="text-[11px] font-mono uppercase text-slate-400 mb-2">
                All 13 Slots Filled (Multi-Word Long-Tail Tokens):
              </div>
              <div className="flex flex-wrap gap-2">
                {selectedProduct.etsyOptimization.thirteenTags.map((tag, i) => (
                  <button
                    key={i}
                    onClick={() => handleCopy(tag, `tag-${i}`)}
                    className="px-2.5 py-1 rounded bg-blue-950/60 hover:bg-blue-900/60 border border-blue-500/30 text-xs font-mono text-blue-200 flex items-center gap-1.5 transition-colors"
                  >
                    <span>#{tag}</span>
                    {copiedKey === `tag-${i}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Maya's Viral Social Campaigns Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Reddit Campaign */}
            <div className="rounded-xl border border-amber-500/40 bg-[#090d18] p-5 shadow-xl glow-amber space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  <span className="font-mono text-xs font-bold text-amber-300 uppercase">
                    Reddit Organic Launch Post
                  </span>
                </div>
                <button
                  onClick={() => handleCopy(selectedProduct.marketingAssets.redditHook, 'reddit')}
                  className="text-slate-400 hover:text-white"
                >
                  {copiedKey === 'reddit' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 leading-relaxed">
                "{selectedProduct.marketingAssets.redditHook}"
              </div>

              <div className="text-[10px] font-mono text-slate-400">
                Target Subreddits: r/Notion, r/digitalnomad, r/SideProject, r/graphic_design. High upvote potential without sounding like spam.
              </div>
            </div>

            {/* X / Twitter Thread */}
            <div className="rounded-xl border border-cyan-500/40 bg-[#090d18] p-5 shadow-xl glow-cyan space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Twitter className="w-4 h-4 text-cyan-400" />
                  <span className="font-mono text-xs font-bold text-cyan-300 uppercase">
                    X Launch Thread Hook
                  </span>
                </div>
                <button
                  onClick={() => handleCopy(selectedProduct.marketingAssets.xThreadHook, 'x')}
                  className="text-slate-400 hover:text-white"
                >
                  {copiedKey === 'x' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 leading-relaxed">
                "{selectedProduct.marketingAssets.xThreadHook}"
              </div>

              <div className="text-[10px] font-mono text-slate-400">
                Optimized for bookmarks and retweets. Follow-up tweet directs to direct checkout with 100% margin.
              </div>
            </div>

            {/* TikTok / Shorts Storyboard */}
            <div className="rounded-xl border border-fuchsia-500/40 bg-[#090d18] p-5 shadow-xl glow-magenta space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Video className="w-4 h-4 text-fuchsia-400" />
                  <span className="font-mono text-xs font-bold text-fuchsia-300 uppercase">
                    TikTok / Shorts Hook
                  </span>
                </div>
                <button
                  onClick={() => handleCopy(selectedProduct.marketingAssets.tikTokScript, 'tiktok')}
                  className="text-slate-400 hover:text-white"
                >
                  {copiedKey === 'tiktok' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 leading-relaxed">
                "{selectedProduct.marketingAssets.tikTokScript}"
              </div>

              <div className="text-[10px] font-mono text-slate-400">
                Visual Hook: 3-second rapid screen recording with cyber aesthetic soundtrack. Link in bio points to storefront.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
