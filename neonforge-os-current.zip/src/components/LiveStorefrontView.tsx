import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Store, 
  Star, 
  Download, 
  ShieldCheck, 
  CreditCard, 
  Check, 
  Lock, 
  Zap, 
  Eye, 
  ArrowRight,
  Sparkles,
  Search,
  CheckCircle2,
  Copy,
  Tag,
  Layers,
  FileCode,
  Flame,
  X,
  SlidersHorizontal,
  Gift,
  Plus,
  Video
} from 'lucide-react';
import { DigitalProduct, Order, Customer } from '../types';
import { playSound } from '../utils/audio';
import { neonforgeApi } from '../services/neonforgeApi';

interface LiveStorefrontViewProps {
  products: DigitalProduct[];
  onPlaceOrder: (order: Order, customer: Customer) => void;
}

export const LiveStorefrontView: React.FC<LiveStorefrontViewProps> = ({
  products,
  onPlaceOrder
}) => {
  const [activeChannel, setActiveChannel] = useState<'store' | 'etsy'>('store');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Inspection Modal State
  const [inspectProduct, setInspectProduct] = useState<DigitalProduct | null>(null);

  // Checkout Drawer / Modal State
  const [selectedProduct, setSelectedProduct] = useState<DigitalProduct | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'payment' | 'processing' | 'success'>('payment');
  const [customerName, setCustomerName] = useState('Alex Rivers');
  const [customerEmail, setCustomerEmail] = useState('alex.rivers@creatorstudios.co');
  const [paymentMethod, setPaymentMethod] = useState<'Credit Card / Stripe' | 'Apple Pay' | 'Etsy Payments'>('Credit Card / Stripe');
  const [recentOrder, setRecentOrder] = useState<Order | null>(null);
  const [copiedKey, setCopiedKey] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);

  // --- DIGITAL PRODUCT OPTIONS & BUMPS STATE ---
  const [selectedLicense, setSelectedLicense] = useState<'Personal Use' | 'Commercial Standard' | 'Extended Resale Pro'>('Commercial Standard');
  const [selectedPackage, setSelectedPackage] = useState<'Standard Asset Vault' | 'Deluxe Creator Studio Bundle'>('Standard Asset Vault');
  const [selectedBumps, setSelectedBumps] = useState<string[]>(['bump_reels_pack']);

  // Price mappings for options
  const licensePriceMap: Record<string, number> = {
    'Personal Use': 0,
    'Commercial Standard': 12,
    'Extended Resale Pro': 29
  };

  const packagePriceMap: Record<string, number> = {
    'Standard Asset Vault': 0,
    'Deluxe Creator Studio Bundle': 15
  };

  const availableBumps = [
    {
      id: 'bump_reels_pack',
      title: '50 Faceless Viral Video Reels + Hooks Pack',
      tagline: 'Ready-to-post short-form video templates for Instagram Reels & TikTok',
      price: 9.99,
      badge: 'POPULAR ADD-ON',
      deliverable: {
        name: '50_Faceless_Reels_Video_Templates.zip',
        size: '142.5 MB',
        format: 'MP4 / Canva Reels Templates',
        contentPreview: '50 Faceless aesthetic reels + viral hook audio templates.'
      }
    },
    {
      id: 'bump_vip_support',
      title: 'VIP Express Priority Delivery & License Certification',
      tagline: '1-on-1 priority support, lifetime update pass & verified certificate',
      price: 14.99,
      badge: 'VIP PASS',
      deliverable: {
        name: 'VIP_Express_License_Certificate.pdf',
        size: '1.2 MB',
        format: 'Verified VIP Certificate',
        contentPreview: 'Priority license validation certificate and direct priority support key.'
      }
    },
    {
      id: 'bump_mrr_resell',
      title: 'Master Resale Rights (MRR) Franchise Pass',
      tagline: 'Sell this product on Etsy or direct store & keep 100% of profits',
      price: 29.99,
      badge: '100% PROFIT',
      deliverable: {
        name: 'Master_Resale_Rights_License_Contract.pdf',
        size: '2.4 MB',
        format: 'MRR Reseller Agreement',
        contentPreview: 'Full Master Resale Rights contract & ready-to-use marketing copy.'
      }
    }
  ];

  // Calculated Price Totals
  const basePrice = selectedProduct?.price || 0;
  const optionsAdjustment = (licensePriceMap[selectedLicense] || 0) + (packagePriceMap[selectedPackage] || 0);
  const bumpsAmount = selectedBumps.reduce((acc, bumpId) => {
    const b = availableBumps.find(item => item.id === bumpId);
    return acc + (b ? b.price : 0);
  }, 0);
  const totalPrice = Number((basePrice + optionsAdjustment + bumpsAmount).toFixed(2));

  // Categories list
  const categories = [
    'ALL',
    'SaaS Blueprints & Neural Tools',
    'AI Prompts & Neural Workflows',
    'Notion & Productivity Systems',
    'Financial Models & Cyber Spreadsheets'
  ];

  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'ALL' || p.niche === selectedCategory;
    const q = (searchQuery || '').toLowerCase();
    const titleMatch = Boolean(p.title && p.title.toLowerCase().includes(q));
    const nicheMatch = Boolean(p.niche && p.niche.toLowerCase().includes(q));
    const subtitleMatch = Boolean(p.subtitle && p.subtitle.toLowerCase().includes(q));
    const matchesQuery = !q || titleMatch || nicheMatch || subtitleMatch;
    return matchesCategory && matchesQuery;
  });

  const handleInspect = (product: DigitalProduct, e: React.MouseEvent) => {
    e.stopPropagation();
    setInspectProduct(product);
    playSound('click');
  };

  const handleOpenCheckout = (product: DigitalProduct) => {
    setSelectedProduct(product);
    setCheckoutStep('payment');
    setIsCheckoutOpen(true);
    setInspectProduct(null);
    playSound('click');
  };

  const toggleBump = (bumpId: string) => {
    playSound('click');
    const bumps = selectedBumps || [];
    if (bumps.includes(bumpId)) {
      setSelectedBumps(bumps.filter(id => id !== bumpId));
    } else {
      setSelectedBumps([...bumps, bumpId]);
    }
  };

  const handleProcessPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || isProcessingPayment) return;

    setPaymentError(null);
    setIsProcessingPayment(true);
    setCheckoutStep('processing');
    playSound('warp');

    const amount = totalPrice;
    const platformFee = activeChannel === 'store' ? Number((amount * 0.029 + 0.30).toFixed(2)) : Number((amount * 0.065 + 0.20).toFixed(2));
    const netProfit = Number((amount - platformFee).toFixed(2));
    const orderNumber = `#NF-${Math.floor(8000 + Math.random() * 2000)}`;

    try {
      // Step 1: Initiate authorized payment session with server to obtain verifiedPaymentToken
      const paymentIntentRes = await fetch('/api/stripe/payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: selectedProduct.id,
          customerEmail,
          customerName,
          orderNumber,
          amount
        })
      });

      let verifiedPaymentToken = '';
      if (paymentIntentRes.ok) {
        const piData = await paymentIntentRes.json();
        verifiedPaymentToken = piData.verifiedPaymentToken || '';
      }

      const orderPayload = {
        order: {
          orderNumber,
          productId: selectedProduct.id,
          productTitle: selectedProduct.title,
          amount,
          platformFee,
          netProfit,
          channel: (activeChannel === 'store' ? 'Direct Storefront' : 'Etsy Sync') as 'Direct Storefront' | 'Etsy Sync',
          paymentMethod: (activeChannel === 'store' ? paymentMethod : 'Etsy Payments') as 'Credit Card / Stripe' | 'Apple Pay' | 'Etsy Payments',
          selectedOptions: {
            'License Tier': selectedLicense,
            'Deliverable Package': selectedPackage
          },
          selectedOrderBumps: selectedBumps,
          optionsPriceAdjustment: optionsAdjustment,
          orderBumpsAmount: bumpsAmount,
          verifiedPaymentToken
        },
        customer: {
          name: customerName || 'Valued Creator',
          email: customerEmail || 'creator@example.com',
          location: 'San Francisco, CA, USA',
        }
      };

      const serverResult = await neonforgeApi.processOrder(orderPayload);
      if (serverResult?.order && serverResult?.customer) {
        setRecentOrder(serverResult.order);
        onPlaceOrder(serverResult.order, serverResult.customer);
        setCheckoutStep('success');
        playSound('cash');
      } else {
        const errMsg = serverResult?.error || 'Payment Required (402): Authoritative payment verification required. Unverified order rejected.';
        setPaymentError(errMsg);
        setCheckoutStep('payment');
        playSound('alert');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn('[Storefront] Order submission error:', msg);
      setPaymentError(`Payment failed: ${msg}`);
      setCheckoutStep('payment');
      playSound('alert');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleDownloadFile = (fileName: string, content?: string) => {
    playSound('click');
    const blob = new Blob([content || `NEONFORGE OS AUTHENTIC DELIVERABLE\nItem: ${selectedProduct?.title}\nLicense: ${recentOrder?.licenseKey}\nStatus: Verified Non-Physical Asset`], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Top Channel Switcher & Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
            <Store className="w-5 h-5 text-cyan-400" />
            <h2 className="font-mono text-lg font-bold uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-amber-400">
              ELECTRIC NEON DIGITAL GOODS STOREFRONT
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-mono">
            Direct creator vault with instant cryptographic license minting, 100% net margin direct payouts, & live Etsy shop sync.
          </p>
        </div>

        {/* Channel Switcher */}
        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => { setActiveChannel('store'); playSound('click'); }}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all ${
              activeChannel === 'store'
                ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-[0_0_15px_rgba(0,243,255,0.4)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>Direct Storefront</span>
          </button>

          <button
            onClick={() => { setActiveChannel('etsy'); playSound('click'); }}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all ${
              activeChannel === 'etsy'
                ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Etsy Sync Channel</span>
          </button>
        </div>
      </div>

      {/* Category Filter Pills & Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0 scrollbar-none">
          {categories.map((cat, i) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={`cat-${i}`}
                onClick={() => { setSelectedCategory(cat); playSound('click'); }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold whitespace-nowrap border transition-all ${
                  isSelected
                    ? 'bg-cyan-950/80 border-cyan-400 text-cyan-300 shadow-[0_0_12px_rgba(0,243,255,0.3)]'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative w-full lg:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search digital assets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-400 transition-colors"
          />
        </div>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredProducts.map((p, index) => {
          const primaryColor = p.mockupTheme?.primaryColor || '#00f0ff';
          const secondaryColor = p.mockupTheme?.secondaryColor || '#ff007f';
          const ratingVal = typeof p.rating === 'number' ? p.rating : 5.0;
          const comparePrice = typeof p.compareAtPrice === 'number' ? p.compareAtPrice : (p.price || 0);
          const currentPrice = typeof p.price === 'number' ? p.price : 0;
          const deliverableLabel = p.deliverableType ? p.deliverableType.replace('_', ' ').toUpperCase() : 'DIGITAL ASSET';
          const licenseLabel = p.licenseType || 'Commercial Standard';

          return (
            <div
              key={`${p.id}-${index}`}
              className="group relative bg-[#090d18] border border-slate-800 hover:border-cyan-500/60 rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-[0_0_25px_rgba(0,243,255,0.2)] hover:-translate-y-1"
            >
              {/* Top Theme Accent Bar */}
              <div 
                className="h-1.5 w-full rounded-full mb-4 opacity-80 group-hover:opacity-100 transition-opacity"
                style={{ background: `linear-gradient(90deg, ${primaryColor}, ${secondaryColor})` }}
              />

              <div className="space-y-3">
                {/* Header Metadata */}
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-400 border border-slate-800 uppercase font-bold">
                    {p.sku}
                  </span>
                  <div className="flex items-center gap-1 text-amber-400 text-xs font-mono font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{ratingVal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Title & Subtitle */}
                <div>
                  <h3 className="font-mono text-base font-bold text-white group-hover:text-cyan-300 transition-colors leading-snug">
                    {p.title}
                  </h3>
                  <p className="text-xs text-slate-300 font-sans line-clamp-2 mt-1">
                    {p.subtitle}
                  </p>
                </div>

                {/* Badges / License */}
                <div className="flex items-center gap-2 flex-wrap text-[10px] font-mono">
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30 font-bold">
                    ⚡ {deliverableLabel}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/30 font-bold">
                    🛡️ {licenseLabel}
                  </span>
                </div>
              </div>

              {/* Price & Action Footer */}
              <div className="pt-4 border-t border-slate-800/80 mt-5 flex items-center justify-between gap-3">
                <div>
                  <span className="text-slate-500 line-through text-[11px] font-mono block">
                    ${comparePrice.toFixed(2)}
                  </span>
                  <span className="text-emerald-400 font-mono text-lg font-bold">
                    ${currentPrice.toFixed(2)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => handleInspect(p, e)}
                    className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors"
                    title="Inspect Product Deliverable Details & Etsy 13 Tags"
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleOpenCheckout(p)}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,243,255,0.3)] transition-all active:scale-95"
                  >
                    <span>Buy Now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Product Quick Inspect Modal */}
      {inspectProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-[#090d18] border border-cyan-500/50 rounded-2xl p-6 shadow-[0_0_35px_rgba(0,243,255,0.25)] max-h-[90vh] overflow-y-auto space-y-5">
            <button
              onClick={() => setInspectProduct(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-start gap-4 border-b border-slate-800/80 pb-4">
              <div 
                className="w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0 border border-cyan-400/40"
                style={{ background: `linear-gradient(135deg, ${inspectProduct.mockupTheme?.primaryColor || '#00f0ff'}, ${inspectProduct.mockupTheme?.secondaryColor || '#ff007f'})` }}
              >
                <Sparkles className="w-8 h-8 text-white" />
              </div>

              <div className="space-y-1 pr-6">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 uppercase font-bold">
                  {inspectProduct.sku} · {inspectProduct.niche}
                </span>
                <h3 className="font-mono text-lg font-bold text-white leading-snug">
                  {inspectProduct.title}
                </h3>
                <p className="text-xs text-slate-300 font-sans">
                  {inspectProduct.subtitle}
                </p>
              </div>
            </div>

            {/* Description & Included Files */}
            <div className="space-y-4">
              <div>
                <h4 className="text-xs font-mono uppercase text-slate-400 mb-1 font-bold">Product Description</h4>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
                  {inspectProduct.description}
                </p>
              </div>

              {/* Key Features */}
              <div>
                <h4 className="text-xs font-mono uppercase text-slate-400 mb-2 font-bold">Key Deliverable Features</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(inspectProduct.features || []).map((feat, i) => (
                    <div key={`feat-${i}`} className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/80 border border-slate-800/80 text-xs font-mono text-slate-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 13 Etsy Search Tags */}
              <div>
                <h4 className="text-xs font-mono uppercase text-amber-400 mb-2 font-bold flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  Etsy 13-Tag SEO Keywords (Built-in Optimization)
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {(inspectProduct.etsyOptimization?.thirteenTags || []).map((tag, i) => (
                    <span key={`tag-${i}`} className="px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-500/30 text-[10px] font-mono">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Price Footer & Instant Checkout */}
            <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-4">
              <div>
                <span className="text-slate-500 line-through text-xs font-mono block">
                  Compare at ${(inspectProduct.compareAtPrice ?? inspectProduct.price ?? 0).toFixed(2)}
                </span>
                <span className="text-emerald-400 font-mono text-xl font-bold">
                  ${(inspectProduct.price ?? 0).toFixed(2)} USD
                </span>
              </div>

              <button
                onClick={() => handleOpenCheckout(inspectProduct)}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-indigo-500 text-black font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-[0_0_20px_rgba(0,253,153,0.3)] transition-all transform active:scale-95"
              >
                <Lock className="w-4 h-4 text-black" />
                <span>Instant Buy Now (${(inspectProduct.price ?? 0).toFixed(2)})</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Multi-Step Checkout & Fulfillment Modal */}
      {isCheckoutOpen && selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-[#0a0e18] border border-cyan-500/50 rounded-2xl p-6 shadow-[0_0_35px_rgba(0,243,255,0.25)] max-h-[92vh] overflow-y-auto">
            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white font-mono text-sm"
            >
              ✕
            </button>

            {checkoutStep === 'payment' && (
              <div className="space-y-5">
                <div className="border-b border-slate-800 pb-3">
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/40 uppercase font-bold">
                    SECURE INSTANT CHECKOUT WITH PRODUCT OPTIONS
                  </span>
                  <h3 className="font-mono text-lg font-bold text-white mt-1">
                    {selectedProduct.title}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-slate-500 line-through text-xs font-mono">
                      ${(selectedProduct.compareAtPrice ?? selectedProduct.price ?? 0).toFixed(2)}
                    </span>
                    <span className="text-emerald-400 text-lg font-mono font-bold">
                      ${totalPrice.toFixed(2)} USD
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">· Instant Download</span>
                  </div>
                </div>

                <form onSubmit={handleProcessPayment} className="space-y-4">
                  {/* Customer Info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-mono uppercase text-slate-300 mb-1 font-bold">
                        Customer Full Name
                      </label>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs font-mono text-white outline-none focus:border-cyan-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono uppercase text-slate-300 mb-1 font-bold">
                        Delivery Email Address
                      </label>
                      <input
                        type="email"
                        required
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs font-mono text-white outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>

                  {/* --- DIGITAL PRODUCT OPTIONS SECTION --- */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-indigo-500/40 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <div className="flex items-center gap-2">
                        <SlidersHorizontal className="w-4 h-4 text-indigo-400" />
                        <span className="text-xs font-mono uppercase text-white font-bold">
                          Configure Product Options & License Rights
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-indigo-300 bg-indigo-950/80 px-2 py-0.5 rounded border border-indigo-500/30">
                        Custom Options
                      </span>
                    </div>

                    {/* Option 1: License Rights Selection */}
                    <div>
                      <label className="block text-[11px] font-mono uppercase text-slate-300 mb-1.5 font-bold">
                        License Rights Tier
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        <button
                          type="button"
                          onClick={() => { setSelectedLicense('Personal Use'); playSound('click'); }}
                          className={`p-2.5 rounded-xl border text-left font-mono transition-all ${
                            selectedLicense === 'Personal Use'
                              ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(0,243,255,0.3)]'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                          }`}
                        >
                          <div className="text-xs font-bold">Personal Use</div>
                          <div className="text-[10px] text-emerald-400 mt-0.5">+$0.00</div>
                        </button>

                        <button
                          type="button"
                          onClick={() => { setSelectedLicense('Commercial Standard'); playSound('click'); }}
                          className={`p-2.5 rounded-xl border text-left font-mono transition-all ${
                            selectedLicense === 'Commercial Standard'
                              ? 'bg-indigo-950/80 border-indigo-400 text-indigo-200 shadow-[0_0_10px_rgba(99,102,241,0.3)]'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                          }`}
                        >
                          <div className="text-xs font-bold flex items-center justify-between">
                            <span>Commercial</span>
                            <span className="text-[9px] bg-indigo-500 text-black px-1 rounded font-black">POPULAR</span>
                          </div>
                          <div className="text-[10px] text-indigo-300 mt-0.5">+$12.00</div>
                        </button>

                        <button
                          type="button"
                          onClick={() => { setSelectedLicense('Extended Resale Pro'); playSound('click'); }}
                          className={`p-2.5 rounded-xl border text-left font-mono transition-all ${
                            selectedLicense === 'Extended Resale Pro'
                              ? 'bg-fuchsia-950/80 border-fuchsia-400 text-fuchsia-200 shadow-[0_0_10px_rgba(217,70,239,0.3)]'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                          }`}
                        >
                          <div className="text-xs font-bold">Extended Resale (MRR)</div>
                          <div className="text-[10px] text-fuchsia-300 mt-0.5">+$29.00</div>
                        </button>
                      </div>
                    </div>

                    {/* Option 2: Deliverable Package Format */}
                    <div>
                      <label className="block text-[11px] font-mono uppercase text-slate-300 mb-1.5 font-bold">
                        Deliverable Package Format
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => { setSelectedPackage('Standard Asset Vault'); playSound('click'); }}
                          className={`p-2.5 rounded-xl border text-left font-mono transition-all ${
                            selectedPackage === 'Standard Asset Vault'
                              ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(0,243,255,0.3)]'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                          }`}
                        >
                          <div className="text-xs font-bold">Standard Asset Vault</div>
                          <div className="text-[10px] text-slate-400 mt-0.5">Master Archive + License PDF</div>
                        </button>

                        <button
                          type="button"
                          onClick={() => { setSelectedPackage('Deluxe Creator Studio Bundle'); playSound('click'); }}
                          className={`p-2.5 rounded-xl border text-left font-mono transition-all ${
                            selectedPackage === 'Deluxe Creator Studio Bundle'
                              ? 'bg-amber-950/80 border-amber-400 text-amber-200 shadow-[0_0_10px_rgba(245,158,11,0.3)]'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                          }`}
                        >
                          <div className="text-xs font-bold flex items-center justify-between">
                            <span>Deluxe Studio Pack</span>
                            <span className="text-[9px] bg-amber-400 text-black px-1 rounded font-black">+$15</span>
                          </div>
                          <div className="text-[10px] text-amber-300 mt-0.5">Raw Source + Canva Templates</div>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* --- CHECKOUT ORDER BUMPS SECTION --- */}
                  <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/40 via-slate-950 to-orange-950/40 border border-amber-500/40 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Gift className="w-4 h-4 text-amber-400" />
                        <span className="text-xs font-mono uppercase text-amber-300 font-bold">
                          Exclusive Checkout Order Bumps (Special Add-Ons)
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-500/40 font-bold animate-pulse">
                        ONE-CLICK ADD
                      </span>
                    </div>

                    <div className="space-y-2">
                      {availableBumps.map((bump) => {
                        const isChecked = Boolean(selectedBumps && selectedBumps.includes(bump.id));
                        return (
                          <div
                            key={bump.id}
                            onClick={() => toggleBump(bump.id)}
                            className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                              isChecked
                                ? 'bg-amber-950/80 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.25)]'
                                : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {}}
                              className="mt-1 w-4 h-4 rounded text-amber-500 focus:ring-amber-400 bg-slate-900 border-slate-700"
                            />

                            <div className="flex-1 space-y-0.5">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                                  {bump.title}
                                </span>
                                <span className="text-xs font-mono font-bold text-amber-400 whitespace-nowrap">
                                  +${bump.price.toFixed(2)}
                                </span>
                              </div>
                              <p className="text-[11px] font-sans text-slate-300">
                                {bump.tagline}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Payment Method Selection */}
                  <div>
                    <label className="block text-xs font-mono uppercase text-slate-300 mb-1.5 font-bold">
                      Payment Gateway Channel
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('Credit Card / Stripe')}
                        className={`p-2.5 rounded-xl border text-[11px] font-mono text-left flex flex-col gap-1 transition-all ${
                          paymentMethod === 'Credit Card / Stripe'
                            ? 'bg-indigo-950/80 border-indigo-400 text-indigo-200 shadow-[0_0_10px_rgba(99,102,241,0.3)]'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 font-bold">
                          <CreditCard className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Stripe Card</span>
                        </div>
                        <span className="text-[9px] text-slate-400">2.9% + 30¢</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentMethod('Apple Pay')}
                        className={`p-2.5 rounded-xl border text-[11px] font-mono text-left flex flex-col gap-1 transition-all ${
                          paymentMethod === 'Apple Pay'
                            ? 'bg-amber-950/80 border-amber-400 text-amber-200 shadow-[0_0_10px_rgba(255,183,0,0.3)]'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 font-bold">
                          <Zap className="w-3.5 h-3.5 text-amber-400" />
                          <span>Apple Pay</span>
                        </div>
                        <span className="text-[9px] text-slate-400">1-Touch Pay</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentMethod('Etsy Payments')}
                        className={`p-2.5 rounded-xl border text-[11px] font-mono text-left flex flex-col gap-1 transition-all ${
                          paymentMethod === 'Etsy Payments'
                            ? 'bg-orange-950/80 border-orange-400 text-orange-200 shadow-[0_0_10px_rgba(249,115,22,0.3)]'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 font-bold">
                          <ShoppingBag className="w-3.5 h-3.5 text-orange-400" />
                          <span>Etsy Sync</span>
                        </div>
                        <span className="text-[9px] text-slate-400">v3 Open API</span>
                      </button>
                    </div>
                  </div>

                  {/* Price Summary Breakdown */}
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5">
                    <div className="flex justify-between text-slate-400">
                      <span>Base Digital Product Price</span>
                      <span>${basePrice.toFixed(2)}</span>
                    </div>
                    {optionsAdjustment > 0 && (
                      <div className="flex justify-between text-indigo-300">
                        <span>Product Options ({selectedLicense})</span>
                        <span>+${optionsAdjustment.toFixed(2)}</span>
                      </div>
                    )}
                    {bumpsAmount > 0 && (
                      <div className="flex justify-between text-amber-300">
                        <span>Selected Order Bumps ({selectedBumps.length})</span>
                        <span>+${bumpsAmount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-white font-bold pt-2 border-t border-slate-800">
                      <span>Total Amount Due</span>
                      <span className="text-cyan-400 font-mono text-base">${totalPrice.toFixed(2)} USD</span>
                    </div>
                  </div>

                  {paymentError && (
                    <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs font-mono flex items-start gap-2">
                      <span className="text-red-400 font-bold">⚠️</span>
                      <div className="flex-1">
                        <div className="font-bold">Payment Authorization Required</div>
                        <div className="text-[11px] text-red-300 mt-0.5">{paymentError}</div>
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-indigo-500 text-black font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,243,255,0.3)] transition-all active:scale-95"
                  >
                    <Lock className="w-4 h-4 text-black" />
                    <span>Authorize Payment & Deliver Goods (${totalPrice.toFixed(2)})</span>
                  </button>
                </form>
              </div>
            )}

            {checkoutStep === 'processing' && (
              <div className="py-12 text-center space-y-4 animate-in fade-in duration-200">
                <div className="w-16 h-16 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin mx-auto flex items-center justify-center">
                  <Zap className="w-6 h-6 text-cyan-400 animate-pulse" />
                </div>
                <h3 className="font-mono text-base font-bold text-white uppercase tracking-wider">
                  Minting Cryptographic License Key & Assembling Deliverables...
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  Settling transaction via {paymentMethod} for ${totalPrice.toFixed(2)}. Packaging options and order bump bonuses.
                </p>
              </div>
            )}

            {checkoutStep === 'success' && (
              <div className="space-y-5 animate-in fade-in duration-300">
                <div className="text-center space-y-1 border-b border-slate-800 pb-4">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  </div>
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 uppercase font-bold">
                    ORDER COMPLETED & SETTLED (${(recentOrder?.amount ?? 0).toFixed(2)})
                  </span>
                  <h3 className="font-mono text-lg font-bold text-white">
                    Fulfillment Vault Ready!
                  </h3>
                  <p className="text-xs text-slate-300 font-mono">
                    Order {recentOrder?.orderNumber} processed via {recentOrder?.paymentMethod}.
                  </p>
                </div>

                {/* License Rights & Options Badge */}
                <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-500/40 text-xs font-mono space-y-1">
                  <div className="text-indigo-300 font-bold flex items-center justify-between">
                    <span>Active License Rights:</span>
                    <span className="bg-indigo-500 text-black px-2 py-0.5 rounded text-[10px] font-black uppercase">
                      {selectedLicense}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Package: <span className="text-white font-bold">{selectedPackage}</span>
                  </p>
                </div>

                {/* Cryptographic License Key Box */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-cyan-500/40 font-mono text-xs space-y-2">
                  <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase">
                    <span>Cryptographic Commercial License Key:</span>
                    <button
                      onClick={() => {
                        if (recentOrder) {
                          navigator.clipboard.writeText(recentOrder.licenseKey);
                          setCopiedKey(true);
                          playSound('click');
                          setTimeout(() => setCopiedKey(false), 1500);
                        }
                      }}
                      className="text-cyan-400 hover:text-white flex items-center gap-1 font-bold"
                    >
                      {copiedKey ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedKey ? 'Copied!' : 'Copy Key'}</span>
                    </button>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-cyan-300 font-bold tracking-widest text-center select-all">
                    {recentOrder?.licenseKey}
                  </div>
                </div>

                {/* Download Deliverables */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono uppercase text-slate-300 block font-bold">
                      Your Deliverable Files & Order Bump Bonuses:
                    </span>
                    {recentOrder && (
                      <button
                        onClick={() => {
                          playSound('click');
                          neonforgeApi.downloadOrderPackage(recentOrder.orderNumber, recentOrder.downloadToken);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400 text-emerald-300 font-mono text-[11px] font-bold flex items-center gap-1.5 transition-colors shadow-[0_0_10px_rgba(0,253,153,0.2)]"
                      >
                        <Download className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Download Full .ZIP Package</span>
                      </button>
                    )}
                  </div>

                  {/* Main Product Deliverables */}
                  {(selectedProduct.deliverableFiles || []).map((file, i) => (
                    <div
                      key={`deliv-${i}`}
                      className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs font-mono"
                    >
                      <div>
                        <div className="text-white font-bold truncate max-w-[220px]">{file.name}</div>
                        <div className="text-slate-400 text-[10px]">{file.format} · {file.size}</div>
                      </div>

                      <button
                        onClick={() => handleDownloadFile(file.name, file.contentPreview)}
                        className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-300 font-mono text-xs font-bold flex items-center gap-1.5 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Download</span>
                      </button>
                    </div>
                  ))}

                  {/* Bonus Order Bumps Deliverables */}
                  {selectedBumps.map((bumpId, i) => {
                    const bump = availableBumps.find(b => b.id === bumpId);
                    if (!bump) return null;
                    return (
                      <div
                        key={`bump-deliv-${i}`}
                        className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between gap-3 text-xs font-mono"
                      >
                        <div>
                          <div className="text-amber-300 font-bold flex items-center gap-1.5 truncate max-w-[220px]">
                            <span>🎁 [BONUS] {bump.deliverable.name}</span>
                          </div>
                          <div className="text-slate-400 text-[10px]">{bump.deliverable.format} · {bump.deliverable.size}</div>
                        </div>

                        <button
                          onClick={() => handleDownloadFile(bump.deliverable.name, bump.deliverable.contentPreview)}
                          className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400 text-amber-300 font-mono text-xs font-bold flex items-center gap-1.5 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5 text-amber-400" />
                          <span>Download</span>
                        </button>
                      </div>
                    );
                  })}
                </div>

                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-[11px] text-emerald-300 font-mono flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Transaction logged to Custom CRM. Customer receipt dispatched.</span>
                </div>

                <button
                  onClick={() => setIsCheckoutOpen(false)}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs font-bold transition-colors"
                >
                  Close & Return to Store
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
