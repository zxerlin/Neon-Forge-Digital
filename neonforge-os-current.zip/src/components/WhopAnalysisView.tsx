import React, { useState } from 'react';
import { 
  LineChart, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp, 
  DollarSign, 
  ShieldAlert, 
  Zap, 
  Layers, 
  ExternalLink,
  Sliders,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { SYSTEM_TEARDOWN } from '../data/mockData';
import { playSound } from '../utils/audio';

export const WhopAnalysisView: React.FC = () => {
  // Interactive 60-day unit economics calculator state
  const [avgPrice, setAvgPrice] = useState(32);
  const [dailyVisitors, setDailyVisitors] = useState(350);
  const [conversionRate, setConversionRate] = useState(2.4);
  const [directStoreRatio, setDirectStoreRatio] = useState(60); // 60% direct store, 40% Etsy

  // Calculated economics
  const dailyOrders = Math.round(dailyVisitors * (conversionRate / 100));
  const monthlyOrders = dailyOrders * 30;
  const monthlyGross = monthlyOrders * avgPrice;

  // Direct fees ~ 3.5% (Stripe), Etsy fees ~ 8.5%
  const blendedFeeRate = (directStoreRatio * 0.035 + (100 - directStoreRatio) * 0.085) / 100;
  const monthlyFees = monthlyGross * blendedFeeRate;
  const monthlyNetProfit = monthlyGross - monthlyFees;

  return (
    <div className="p-4 lg:p-6 space-y-8">
      {/* Top Banner */}
      <div className="rounded-xl border border-purple-500/40 bg-gradient-to-r from-[#140b24] via-[#0d0718] to-[#140b24] p-5 glow-purple">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/40 uppercase font-bold">
                FORENSIC DECONSTRUCTION & SUPERIOR BLUEPRINT
              </span>
              <span className="text-xs font-mono text-purple-400">Target: Whop AI Agent Academy</span>
            </div>
            <h2 className="font-mono text-lg font-bold text-white uppercase tracking-wide">
              LANDING PAGE AUDIT & 60-DAY REALITY BLUEPRINT
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Why the Whop "AI Agent Academy" model has massive marketing hype but collapses in practical execution — and how NeonForge OS fixes every structural flaw to generate sustainable $3,000–$5,000+/mo income in 60 days.
            </p>
          </div>

          <div className="bg-black/60 border border-purple-500/30 rounded-lg p-3 text-right">
            <span className="text-[10px] font-mono uppercase text-slate-400 block">Unit Economics Simulator</span>
            <span className="text-lg font-mono font-bold text-emerald-400">Model: $4,500/mo Target</span>
          </div>
        </div>
      </div>

      {/* Part 1: Deep Teardown of the User's Video & Screenshots */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Flaws in the Whop / Agent Academy Model */}
        <div className="rounded-xl border border-red-500/30 bg-[#090d18] p-5 space-y-4">
          <div className="flex items-center gap-2 text-red-400 border-b border-slate-800 pb-3">
            <ShieldAlert className="w-5 h-5 text-red-400" />
            <h3 className="font-mono text-sm font-bold text-white uppercase">
              The 4 Fatal Flaws in the "AI Agent Academy" System
            </h3>
          </div>

          <div className="space-y-3">
            {SYSTEM_TEARDOWN.whopAcademyAnalysis.keyWeaknesses.map((item, idx) => (
              <div key={idx} className="p-3 rounded-lg bg-slate-950/80 border border-slate-800/80 space-y-1">
                <div className="flex items-center gap-2 text-xs font-mono font-bold text-red-400">
                  <span>0{idx + 1}.</span>
                  <span>{item.title}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pl-5">
                  {item.detail}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Why NeonForge OS is Radically Superior */}
        <div className="rounded-xl border border-cyan-500/30 bg-[#090d18] p-5 space-y-4 glow-cyan">
          <div className="flex items-center gap-2 text-cyan-400 border-b border-slate-800 pb-3">
            <Zap className="w-5 h-5 text-cyan-400" />
            <h3 className="font-mono text-sm font-bold text-white uppercase">
              How NeonForge OS Solves Every Bottleneck
            </h3>
          </div>

          <div className="space-y-3">
            {SYSTEM_TEARDOWN.whopAcademyAnalysis.neonForgeAdvantage.map((adv, idx) => (
              <div key={idx} className="p-3 rounded-lg bg-slate-950/80 border border-slate-800/80 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-slate-200 leading-relaxed font-mono">
                  {adv}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Part 2: Interactive 60-Day Unit Economics Calculator */}
      <div className="rounded-xl border border-cyan-500/40 bg-[#090d18] p-5 shadow-2xl glow-cyan space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 uppercase font-bold">
              GROUNDED FINANCIAL MODEL
            </span>
            <h3 className="font-mono text-base font-bold text-white mt-1">
              Realistic Digital Goods Unit Economics & Net Profit Simulator
            </h3>
          </div>

          <span className="text-xs font-mono text-slate-400">
            Based on actual Etsy & Direct Store benchmark metrics
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Slider 1: Average Price */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400 uppercase">Average Product Price</span>
              <span className="text-cyan-400 font-bold">${avgPrice}.00</span>
            </div>
            <input
              type="range"
              min="15"
              max="79"
              step="1"
              value={avgPrice}
              onChange={(e) => {
                setAvgPrice(Number(e.target.value));
                playSound('click');
              }}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 font-mono flex justify-between">
              <span>$15 (Template)</span>
              <span>$79 (Bundle)</span>
            </div>
          </div>

          {/* Slider 2: Daily Visitors */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400 uppercase">Daily Organic Visitors</span>
              <span className="text-cyan-400 font-bold">{dailyVisitors} visitors</span>
            </div>
            <input
              type="range"
              min="50"
              max="1500"
              step="25"
              value={dailyVisitors}
              onChange={(e) => {
                setDailyVisitors(Number(e.target.value));
                playSound('click');
              }}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 font-mono flex justify-between">
              <span>50 / day</span>
              <span>1,500 / day</span>
            </div>
          </div>

          {/* Slider 3: Conversion Rate */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400 uppercase">Conversion Rate</span>
              <span className="text-cyan-400 font-bold">{conversionRate.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="5.0"
              step="0.1"
              value={conversionRate}
              onChange={(e) => {
                setConversionRate(Number(e.target.value));
                playSound('click');
              }}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 font-mono flex justify-between">
              <span>1.0% (Average)</span>
              <span>5.0% (High Hook)</span>
            </div>
          </div>

          {/* Slider 4: Channel Split */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400 uppercase">Direct Store vs Etsy</span>
              <span className="text-cyan-400 font-bold">{directStoreRatio}% Direct</span>
            </div>
            <input
              type="range"
              min="10"
              max="90"
              step="5"
              value={directStoreRatio}
              onChange={(e) => {
                setDirectStoreRatio(Number(e.target.value));
                playSound('click');
              }}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 font-mono flex justify-between">
              <span>10% Direct</span>
              <span>90% Direct</span>
            </div>
          </div>
        </div>

        {/* Calculated Monthly Income Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-2">
          <div className="p-4 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400 block">Monthly Units Sold</span>
            <div className="text-xl font-mono font-bold text-white mt-0.5">{monthlyOrders} Orders</div>
            <span className="text-[11px] text-slate-400 font-mono">~{dailyOrders} orders / day</span>
          </div>

          <div className="p-4 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400 block">Gross Revenue</span>
            <div className="text-xl font-mono font-bold text-cyan-300 mt-0.5">${monthlyGross.toLocaleString()}</div>
            <span className="text-[11px] text-slate-400 font-mono">0 physical costs</span>
          </div>

          <div className="p-4 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400 block">Platform & Processing</span>
            <div className="text-xl font-mono font-bold text-red-400 mt-0.5">-${monthlyFees.toFixed(0)}</div>
            <span className="text-[11px] text-slate-400 font-mono">{(blendedFeeRate * 100).toFixed(1)}% blended fee</span>
          </div>

          <div className="p-4 rounded-lg bg-emerald-950/40 border border-emerald-500/50 glow-lime">
            <span className="text-[10px] font-mono uppercase text-emerald-400 block font-bold">Pure Net Profit in Pocket</span>
            <div className="text-2xl font-mono font-extrabold text-emerald-300 mt-0.5">
              ${monthlyNetProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })} / mo
            </div>
            <span className="text-[11px] text-emerald-400 font-mono">95.4% Net Margin</span>
          </div>
        </div>
      </div>

      {/* Part 3: Step-by-Step 60-Day Reality Roadmap */}
      <div className="rounded-xl border border-slate-800 bg-[#090d18] p-5 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <h3 className="font-mono text-base font-bold text-white uppercase">
            60-Day Proven Execution Roadmap (From Zero to $4,500+/mo)
          </h3>
        </div>

        <div className="space-y-4">
          {SYSTEM_TEARDOWN.sixtyDayIncomeRoadmap.map((phase, idx) => (
            <div key={idx} className="p-4 rounded-lg bg-slate-950 border border-slate-800/80 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="font-mono text-xs font-bold text-cyan-400">{phase.phase}</span>
                <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  Target: {phase.targetRevenue}
                </span>
              </div>

              <ul className="space-y-1.5 pt-1">
                {phase.milestones.map((m, mIdx) => (
                  <li key={mIdx} className="flex items-start gap-2 text-xs font-mono text-slate-300">
                    <ArrowRight className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0 mt-0.5" />
                    <span>{m}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
